package homeworks;

public class sum {

    static void main() {


        int a = 90;
        int b = 80;

        System.out.println(a+b);
        System.out.println(a-b);
        System.out.println(a*b);
        System.out.println(a/b);
        System.out.println(a%b);

    }
}
