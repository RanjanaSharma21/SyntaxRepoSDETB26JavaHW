package homeworks;

public class array2 {

    static void main() {

        int [] score = {85,72, 90, 67, 88, 95};

        int count = 0;

        for (int i = 0; i < score.length; i++) {

            if (score[i] > 80) {
                count++;

            }

        }

        System.out.println("Number of scores above 80: " + count);


    }
}
