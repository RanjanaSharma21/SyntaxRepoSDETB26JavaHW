package homeworks;

public class loop {

    static void main() {


        String [] fruits = { "apple", "banana", "orange", "pinappel", "cherry" };

        for (String fruit : fruits) {

            System.out.println(fruit);
        }

    }
}
