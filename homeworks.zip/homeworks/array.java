package homeworks;

public class array {

    static void main() {

      int [] numbers= {10, 20, 30, 40, 50};
      int sum = 0;

      for ( int i = 0; i < numbers.length; i++) {
          sum += numbers[i];


          System.out.println(numbers[i]);

      }

        double average = (double) sum / numbers.length;
      System.out.println("average" + average);

    }
}
